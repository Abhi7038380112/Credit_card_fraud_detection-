import streamlit as st
import pandas as pd
import numpy as np
import json
import re

st.set_page_config(page_title="Credit Card Fraud Prediction", page_icon="💳", layout="wide")

@st.cache_resource
def load_artifacts():
    with open("feature_names.json", "r") as f:
        feature_names = json.load(f)
    with open("preproc_stats.json", "r") as f:
        pre = json.load(f)
    with open("model_params.json", "r") as f:
        model = json.load(f)
    # Convert to numpy arrays
    med = np.array(pre["medians"], dtype=float)
    mu = np.array(pre["means"], dtype=float)
    sigma = np.array(pre["stds"], dtype=float)
    coef = np.array(model["coef"], dtype=float).reshape(-1)
    intercept = float(model["intercept"])
    return feature_names, med, mu, sigma, coef, intercept

def parse_pasted_text(text, expected_cols):
    lines = [ln.strip() for ln in text.strip().splitlines() if ln.strip()]
    rows = []
    for ln in lines:
        # If commas present, split by comma; else normalize tabs/spaces to comma then split
        if "," in ln:
            parts = [s.strip() for s in ln.split(",") if s.strip() != ""]
        else:
            ln = ln.replace("\t", " ")
            ln = re.sub(r"\s+", " ", ln)
            parts = [s.strip() for s in ln.split(" ") if s.strip() != ""]
        rows.append(parts)
    if not rows:
        raise ValueError("No values detected. Paste at least one row of numbers.")
    n_expected = len(expected_cols)
    for i, r in enumerate(rows, start=1):
        if len(r) != n_expected:
            raise ValueError(f"Row {i} has {len(r)} values, expected {n_expected}.\n"
                             f"Expected order: {', '.join(expected_cols)}")
    data = [[float(x) for x in r] for r in rows]
    return pd.DataFrame(data, columns=expected_cols)

def preprocess_numpy(df, feature_names, med, mu, sigma):
    X = df[feature_names].to_numpy(dtype=float)
    # Replace inf -> nan
    X[np.isinf(X)] = np.nan
    # Impute NaNs with medians
    # Find NaNs mask
    nan_mask = np.isnan(X)
    if nan_mask.any():
        # Broadcast medians across rows
        X[nan_mask] = np.take(med, np.where(nan_mask)[1])
    # Standardize
    X_scaled = (X - mu) / sigma
    return X_scaled

def predict_proba(X_scaled, coef, intercept):
    # Logistic function
    logits = X_scaled @ coef + intercept
    proba_pos = 1.0 / (1.0 + np.exp(-logits))
    return proba_pos

def main():
    st.title("💳 Credit Card Fraud Prediction — Paste Values Only (No sklearn)")
    st.write("Paste values for the features below (same order). **No file upload. No CSV output.**")

    feature_names, med, mu, sigma, coef, intercept = load_artifacts()

    with st.expander("Required feature order"):
        st.code(", ".join(feature_names), language="text")

    example = ",".join(["0"] * len(feature_names))
    text = st.text_area("Paste rows (one per line). Use commas, tabs, or spaces between numbers.",
                        value=example, height=140)

    threshold = st.slider("Decision Threshold (fraud if probability ≥ threshold)",
                          min_value=0.05, max_value=0.95, value=0.50, step=0.01)

    if st.button("Predict"):
        try:
            df = parse_pasted_text(text, feature_names)
            X_scaled = preprocess_numpy(df, feature_names, med, mu, sigma)
            proba = predict_proba(X_scaled, coef, intercept)
            preds = (proba >= threshold).astype(int)

            out = df.copy()
            out["fraud_probability"] = proba
            out["prediction"] = preds

            st.subheader("Results")
            st.dataframe(out, use_container_width=True)

            st.markdown(
                f"**Summary:** Total rows: {len(out)} | "
                f"Predicted Fraud: {int(out['prediction'].sum())} | "
                f"Threshold: {threshold:.2f}"
            )

            with st.expander("Interpretation"):
                st.write("- `fraud_probability` is between 0 and 1; higher = more likely fraud.")
                st.write("- `prediction` is 1 if probability ≥ threshold, else 0.")

        except Exception as e:
            st.error(f"Error: {e}")
            st.info("Make sure each line has exactly the required number of values in the correct order.")

    st.caption("Tip: Copy cells for V1..V28 and Amount from Excel (no headers) and paste here.")

if __name__ == "__main__":
    main()
